# 基础
import time
import threading
# fastapi
import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
# 定时
from apscheduler.schedulers.background import BackgroundScheduler
# 日志
import logging
# 自编模块
from scr.iot_server import IotServer, DataMsg, CommandMsg
from scr.mysql_operation import DB
from scr.tx_api import TX_API

api_server = FastAPI()
iot_server = IotServer()
db = DB()
tx_api = TX_API()
logger = logging.getLogger('logger')

# 定时任务
plan = BackgroundScheduler(timezone='Asia/Shanghai')

# 解决FastAPI跨域问题
api_server.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 允许访问的源
    allow_credentials=True,  # 支持 cookie
    allow_methods=["*"],  # 允许使用的请求方法
    allow_headers=["*"]  # 允许携带的 Headers
)


# 定时任务-给设备发送天气数据
def send_weather():
    logger.info(f'获取天气……')
    weather = tx_api.get_weather()
    logger.info(f'天气情况{weather}')
    for k, v in weather.items():
        for sq in [i['sq'] for i in iot_server.conns.values() if i['iot']]:
            sq.put(DataMsg(f'{k}_{v}'))


@iot_server.after_receive
def iot_registration(conn, data, s='Message from ESP32 and STM32', ):
    """
    设备认证，当收到的数据为’s‘时，将连接放入已经认证的设备列表
    """
    sq = iot_server.conns[conn]['sq']
    try:
        data = data.decode('utf-8')
    except UnicodeDecodeError:
        logger.error('编码错误！')
        return
    if data.strip() == s:
        # 将连接放入已经认证的设备列表
        iot_server.conns[conn]['iot'] = True
        # 发送时间，表示认证成功
        sq.put(DataMsg(f'{time.strftime("%y-%m-%d %H-%M-%S", time.localtime())}', level=90))
        return True


@iot_server.after_receive
def save_data(conn, data):
    """
    数据入库
    """
    try:
        data = data.decode('utf-8')
    except UnicodeDecodeError:
        logger.error('编码错误！')
        return
    if ':' not in data:
        return
    for i in data.split(';'):
        if ':' in i and 'end' not in i:
            k, v = i.split(':')
            logger.info(f'数据入库: {k}: {v}')
            db.save_data(k, v)


@api_server.api_route('/iot/list', methods=['post', 'get'])
def api_iot_list():
    """
    查看数据库里保存的数据都有什么数据类型
    """
    return db.iot_list()


@api_server.api_route('/iot/{name}', methods=['post', 'get'])
def api_iot_someone_data(name):
    """
    参数：数据类型
    返回：对应数据的全部数据
    """
    if name in db.iot_list():
        return db.iot_someone_data(name)


@api_server.api_route('/iot/send/command', methods=['post'])
def send_command(command):
    for i in [v['sq'] for v in iot_server.conns.values() if v['iot']]:
        i.put(CommandMsg(command))
    return True


if __name__ == '__main__':
    # 单线程运行iot_server
    # iot_server.main()
    # 定时任务
    plan.add_job(send_weather, 'interval', seconds=1800)
    plan.start()
    # 多线程运行iot_server
    thread = threading.Thread(target=iot_server.run, name='IotServer_Main', daemon=True).start()

    # 运行api_server
    uvicorn.run(api_server, host='0.0.0.0', port=12588)
