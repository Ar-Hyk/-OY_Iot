import time

import pymysql


class DB:
    def __init__(self):
        self.host = '127.0.0.1'  # 本地127.0.0.1
        # self.host = '20.255.58.209'
        self.user = 'iot_admin'  # 用户名
        self.passwd = 'admin_iot'  # 密码
        self.port = 3306  # 默认为3306
        self.db = 'iot'  # 数据库名称
        self.charset = 'utf8'  # 字符编码
        self.conn = pymysql.connect(
            host=self.host,
            user=self.user,
            passwd=self.passwd,
            port=self.port,
            db=self.db,
            charset=self.charset
        )
        self.cur = self.conn.cursor()

    def update_conn(self):
        self.conn = pymysql.connect(
            host=self.host,
            user=self.user,
            passwd=self.passwd,
            port=self.port,
            db=self.db,
            charset=self.charset
        )
        self.cur = self.conn.cursor()

    def save_data(self, k, v):
        t = int(time.time() * 10)
        sql = f"INSERT INTO `iot`.`iot` (`t`, `type`, `value`) VALUES ({t}, '{k}', '{v}')"
        try:
            self.cur.execute(sql)
            self.conn.commit()
        except Exception as e:
            print(sql)
            print(e)
            # self.update_conn()

    def iot_list(self):
        iot_list = []
        sql = 'SELECT iot.type FROM	iot GROUP BY iot.type'
        try:
            self.cur.execute(sql)
        except Exception:
            self.update_conn()
            self.cur.execute(sql)
        for i in self.cur.fetchall():
            iot_list.append(*i)
        return iot_list

    def iot_someone_data(self, name):
        data = []
        sql = f"SELECT iot.type,iot.`value`,iot.t FROM iot WHERE iot.type = '{name}' ORDER BY iot.t"
        try:
            self.cur.execute(sql)
        except Exception:
            self.update_conn()
            self.cur.execute(sql)
        for i in self.cur.fetchall():
            data.append(zip(['type', 'value', 't'], i))
        return data


if __name__ == '__main__':
    db = DB()
